# 🎮 Tic-Tac-Toe AI Game

A fun, web-based Tic-Tac-Toe game where you play against a smart AI using the **Minimax algorithm**!  
Built with **Flask (Python)** for the backend and **HTML/CSS/JavaScript** for the frontend.

---

## ✨ Features

- 🔢 **Minimax AI** that makes unbeatable moves
- 🧠 Choose your symbol (X or O) before playing
- 🥇 First move advantage for the previous winner
- 📈 Score tracking: player, AI, and draws
- 🖼️ Beautiful responsive UI with winning cell highlights
- 🔄 Restart game without refreshing the page

---

## 🖥️ Screenshots

> Add a few screenshots here showing:
> - Player symbol selection
> - Game board
> - Win/draw scenarios
> - Score tracking

---

## 🚀 How to Run Locally

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/tic-tac-toe-ai.git
cd tic-tac-toe-ai



2. Install Python Dependencies

pip install flask flask-cors

3. Run the Flask Backend

python app.py



⚙️ Technologies Used
Python + Flask – backend server and AI logic

HTML/CSS/JS – frontend game UI

Minimax Algorithm – for unbeatable AI

Vanilla JavaScript – no frontend frameworks

👤 Author
[Your Name]
GitHub: @yourusername