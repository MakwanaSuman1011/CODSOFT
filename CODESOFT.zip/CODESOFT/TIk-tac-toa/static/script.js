let board = Array(9).fill("");
let player = "X";
let ai = "O";
let gameOver = false;
let currentTurn = "player";  // Whose turn is it now
let lastWinner = "player";   // Who won last

let playerScore = 0, aiScore = 0, drawScore = 0;

const boardEl = document.getElementById("board");
const statusEl = document.getElementById("status");
const turnEl = document.getElementById("turn");

function renderBoard() {
  boardEl.innerHTML = "";
  board.forEach((val, i) => {
    const cell = document.createElement("div");
    cell.className = "cell";
    cell.textContent = val;
    cell.onclick = () => handleClick(i);
    boardEl.appendChild(cell);
  });
}

function handleClick(i) {
  if (board[i] || gameOver || currentTurn !== "player") return;

  board[i] = player;
  currentTurn = "ai";
  renderBoard();
  checkGameOver(player);

  if (!gameOver) {
    turnEl.textContent = "AI's turn...";
    setTimeout(aiMakeMove, 500);
  }
}

function aiMakeMove() {
  fetch("/ai-move", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ board, player }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.move !== -1 && !board[data.move]) {
        board[data.move] = ai;
        renderBoard();
        checkGameOver(ai);
      }
      if (!gameOver) {
        currentTurn = "player";
        turnEl.textContent = "Your turn!";
      }
    });
}

function checkGameOver(symbol) {
  const winPatterns = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];

  for (let pattern of winPatterns) {
    const [a, b, c] = pattern;
    if (board[a] && board[a] === board[b] && board[b] === board[c]) {
      gameOver = true;

      // Highlight winning cells
      const cells = document.getElementsByClassName("cell");
      [a, b, c].forEach(index => {
        cells[index].classList.add("win");
      });

      if (symbol === player) {
        statusEl.textContent = "🎉 You win!";
        playerScore++;
        lastWinner = "player";
      } else {
        statusEl.textContent = "😔 AI wins!";
        aiScore++;
        lastWinner = "ai";
      }

      updateScores();
      return;
    }
  }

  if (!board.includes("")) {
    gameOver = true;
    statusEl.textContent = "🤝 It's a draw!";
    drawScore++;
    lastWinner = "player"; // Let player start after draw
    updateScores();
  }
}

function updateScores() {
  document.getElementById("playerScore").textContent = playerScore;
  document.getElementById("aiScore").textContent = aiScore;
  document.getElementById("drawScore").textContent = drawScore;
}

function restartGame() {
  board = Array(9).fill("");
  gameOver = false;
  statusEl.textContent = "";
  renderBoard();

  if (lastWinner === "ai") {
    currentTurn = "ai";
    turnEl.textContent = "AI's turn...";
    setTimeout(aiMakeMove, 500);
  } else {
    currentTurn = "player";
    turnEl.textContent = "Your turn!";
  }
}

function chooseSymbol(chosen) {
  player = chosen;
  ai = player === "X" ? "O" : "X";

  document.getElementById("symbolSelection").style.display = "none";
  document.getElementById("gameArea").style.display = "block";

  restartGame();
}

// Initial render
renderBoard();
