# from flask import Flask, render_template, request, jsonify
# import math

# app = Flask(__name__)

# # Check winner
# def check_winner(board, player):
#     win_patterns = [
#         [0,1,2], [3,4,5], [6,7,8],    # rows
#         [0,3,6], [1,4,7], [2,5,8],    # cols
#         [0,4,8], [2,4,6]              # diagonals
#     ]
#     return any(all(board[i] == player for i in pattern) for pattern in win_patterns)

# # Check draw
# def is_draw(board):
#     return all(cell != '' for cell in board)

# # Minimax
# def minimax(board, is_max):
#     if check_winner(board, 'O'):
#         return 1
#     if check_winner(board, 'X'):
#         return -1
#     if is_draw(board):
#         return 0

#     best = -math.inf if is_max else math.inf
#     for i in range(9):
#         if board[i] == '':
#             board[i] = 'O' if is_max else 'X'
#             score = minimax(board, not is_max)
#             board[i] = ''
#             best = max(best, score) if is_max else min(best, score)
#     return best

# # AI move
# def best_move(board):
#     best_score = -math.inf
#     move = -1
#     for i in range(9):
#         if board[i] == '':
#             board[i] = 'O'
#             score = minimax(board, False)
#             board[i] = ''
#             if score > best_score:
#                 best_score = score
#                 move = i
#     return move

# @app.route("/")
# def index():
#     return render_template("index.html")

# @app.route("/ai-move", methods=["POST"])
# def ai():
#     data = request.json
#     board = data['board']
#     move = best_move(board)
#     return jsonify({"move": move})

# if __name__ == "__main__":
#     app.run(debug=True)


from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import math

app = Flask(__name__, static_url_path='/static')
CORS(app)

# --- Helper Functions ---

def is_winner(board, player):
    win_patterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],     # rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],     # cols
        [0, 4, 8], [2, 4, 6]                 # diagonals
    ]
    return any(all(board[i] == player for i in pattern) for pattern in win_patterns)

def is_draw(board):
    return all(cell != '' for cell in board)

def available_moves(board):
    return [i for i, val in enumerate(board) if val == '']

def minimax(board, is_maximizing, ai, human):
    if is_winner(board, ai): return 1
    if is_winner(board, human): return -1
    if is_draw(board): return 0

    if is_maximizing:
        best_score = -math.inf
        for move in available_moves(board):
            board[move] = ai
            score = minimax(board, False, ai, human)
            board[move] = ''
            best_score = max(score, best_score)
        return best_score
    else:
        best_score = math.inf
        for move in available_moves(board):
            board[move] = human
            score = minimax(board, True, ai, human)
            board[move] = ''
            best_score = min(score, best_score)
        return best_score

# --- Routes ---

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/ai-move', methods=['POST'])
def ai_move():
    data = request.get_json()
    board = data['board']
    human = data['player']
    ai = 'O' if human == 'X' else 'X'

    best_score = -math.inf
    best_move = -1
    for move in available_moves(board):
        board[move] = ai
        score = minimax(board, False, ai, human)
        board[move] = ''
        if score > best_score:
            best_score = score
            best_move = move

    return jsonify({'move': best_move})


if __name__ == '__main__':
    app.run(debug=True)
